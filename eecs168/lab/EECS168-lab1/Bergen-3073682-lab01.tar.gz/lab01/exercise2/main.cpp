#include <iostream>

	int main() {
	
	std::cout	<< "My name is Morgan Bergen.\n"
		  	<< "I am an EECS major\n"
		  	<< "My hobbies are:\n"
		  	<< "\t Tennis \n"
			<< "\t Filmmaking \n"
			<< "\t People Watching \n"
			<< "\t Surfing the World Wide Web \n"
			<< "Goodbye \n";

		return 0;
	}
